import 'package:flutter/material.dart';

Color myCustomColor =  Colors.deepPurple;